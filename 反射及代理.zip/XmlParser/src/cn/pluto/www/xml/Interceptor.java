package cn.pluto.www.xml;

public class Interceptor {
	private String name;
	private ActionClass ac;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public ActionClass getAc() {
		return ac;
	}
	
	public void setAc(ActionClass ac) {
		this.ac = ac;
	}
}
