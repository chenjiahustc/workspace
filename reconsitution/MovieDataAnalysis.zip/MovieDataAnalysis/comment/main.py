#-*- coding: utf-8 -*-
import DivisionWord
import MySQLdb
from Comment import Comment

def connectDB(ahost = '219.219.220.119', auser = 'root', apasswd='', aport = 3306, acharset='utf8'):
    try:
        conn = MySQLdb.connect(host = ahost, user = auser, passwd = apasswd, port = aport, charset = acharset)
        return conn
    except Exception, e:
        print str(e)



def main():
    remark = u"周冬雨和马思纯演得挺好，不过我是冲着导演去的。两个女生角色的塑造其实就是大多数青春小说里常见的人设，坏女孩和乖女孩啊。剧情有点老套而且太俗了吧，讲两个女生的故事为什么每次都是为了男人撕逼啊，少女哪吒也是……看得我不爽。最后结局真的太好猜，我希望的百合场景果然没有(._.)"
    cm = Comment()
    conn = connectDB()
    cur = conn.cursor()
    conn.select_db("movies")
    comm = ""



    cm.calScore(remark)
    print cm.movieScore


if __name__ == "__main__":
    main()
