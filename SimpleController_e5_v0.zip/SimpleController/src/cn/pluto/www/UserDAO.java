package cn.pluto.www;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class UserDAO {
	private static String url = "jdbc:mysql://localhost:3306/j2ee_db";
	private static String driver = "com.mysql.jdbc.Driver";
	private static String username = "root";
	private static String password = "hello";

	public Connection openDBConnection(){
		Connection conn = null;
		
		try{
			Class.forName(driver);
			conn = DriverManager.getConnection(url, username, password);
		} catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	
	public boolean closeDBConnection(Connection conn){
		try{
			conn.close();
		} catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public UserBean queryUser(String userName){
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from users where Username=?";
		UserBean ub = new UserBean();
		
		try{
			conn = openDBConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			rs = ps.executeQuery();
			
			if (rs != null){
				if (rs.next()){
					String password = rs.getString(2);
					ub.setUsername(userName);
					ub.setPassword(password);
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
		if (rs != null){
			try{
				rs.close();
			} catch (Exception e){
				e.printStackTrace();
			}
			
			rs = null;
		}
		
		if (ps != null){
			try{
				ps.close();
			} catch(Exception e){
				e.printStackTrace();
			}
			
			ps = null;
		}
		
		if (conn != null)
			closeDBConnection(conn);
		
		return ub;
	}
	
	public boolean insertUser(UserBean u){
		Connection conn = null;
		PreparedStatement ps = null;
		int result = 0;
		String sql = "insert into users values(?, ?)";
		
		try{
			conn = openDBConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, u.getUsername());
			ps.setString(2, u.getPassword());
			result = ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
		if (ps != null){
			try{
				ps.close();
			} catch(Exception e){
				e.printStackTrace();
			}
			
			ps = null;
		}
		
		if (conn != null)
			closeDBConnection(conn);
		
		if (result == 1)
			return true;
		else
			return false;
	}
	
	public boolean updateUser(UserBean u){
		Connection conn = null;
		PreparedStatement ps = null;
		int result = 0;
		String sql = "update users set Username=?, Password=? where Username=?";
		
		try{
			conn = openDBConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, u.getUsername());
			ps.setString(2, u.getPassword());
			ps.setString(3, u.getUsername());
			result = ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
		if (ps != null){
			try{
				ps.close();
			} catch(Exception e){
				e.printStackTrace();
			}
			
			ps = null;
		}
		
		if (conn != null)
			closeDBConnection(conn);
		
		if (result == 1)
			return true;
		else
			return false;
	}
	
	public boolean deleteUser(UserBean u){
		Connection conn = null;
		PreparedStatement ps = null;
		int result = 0;
		String sql = "delete from users where Username=?";
		
		try{
			conn = openDBConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, u.getUsername());
			result = ps.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		
		if (ps != null){
			try{
				ps.close();
			} catch(Exception e){
				e.printStackTrace();
			}
			
			ps = null;
		}
		
		if (conn != null)
			closeDBConnection(conn);
		
		if (result == 1)
			return true;
		else
			return false;
	}
	
}
