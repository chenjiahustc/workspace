package cn.pluto.www;

import java.sql.ResultSet;

public class UserService {
	public boolean checkLogin(User user){
		ResultSet rs = null;
		String sql = "select * from users where Username=?";
		String password = null;
		String parameters[] = {user.getUsername()};
		
		rs = SqlHelper.executeQuery(sql, parameters);
		
		if (rs != null)
			try{
				if (rs.next()){
					password = rs.getString(2);
					if (password.equals(user.getPassword()))
						return true;
					else
						return false;
				}
				else
					return false;
			}catch(Exception e){
				e.printStackTrace();
			} finally{
				SqlHelper.close();
			}
		else{
			SqlHelper.close();
			return false;
		}
		
		return false;
	}
}
