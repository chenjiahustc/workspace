package cn.pluto.www;

public class HelloWorldImpl implements HelloWorld{
	public void sayHelloWorld(){
		System.out.println("Hello World!");
	}
}
