package cn.pluto.www;

public interface HelloWorld {
	public void sayHelloWorld();
}
