package cn.pluto.www;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Servlet implementation class UserBean
 */
@WebServlet("/UserBean")
public class UserBean extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserBean() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = getServletContext();
		RequestDispatcher dispatcher = null;
		Connection conn = null;
		String sql;
		String username = null;
		String password = null;
		String c_passwd = null;
		J2ee_db db = null;
		
		username = request.getParameter("username");
		password = request.getParameter("password");
		
		
		try {
			db = new J2ee_db();
			c_passwd = db.getPassword("test");

        } catch (Exception e) {
            System.out.print("MYSQL ERROR:" + e.getMessage());
        }
        
		if (c_passwd.equals(password))
			dispatcher = context.getRequestDispatcher("/login_success.jsp");
		else
			dispatcher = context.getRequestDispatcher("/login_fail.jsp");
		
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
