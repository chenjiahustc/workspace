package cn.pluto.www;

import java.sql.ResultSet;

public class UserBean {
	public boolean checkLogin(User user){
		ResultSet rs = null;
		String sql = "select * from users where Username=?";
		String password = null;
		String parameters[] = {user.getUsername()};
		
		rs = SqlHelper.executeQuery(sql, parameters);
		
		if (rs != null)
			try{
				if (rs.next()){
					password = rs.getString(2);
					if (password.equals(user.getPassword()))
						return true;
					else
						return false;
				}
				else
					return false;
			}catch(Exception e){
				e.printStackTrace();
			} finally{
				SqlHelper.close();
			}
		else{
			SqlHelper.close();
			return false;
		}
		
		return false;
	}
	
	public boolean registerUser(User user){
		int  result = 0;
		String sql = "insert into users values(?, ?)";
		String password = null;
		String parameters[] = {user.getUsername(), user.getPassword()};
		
		result = SqlHelper.executeUpdate(sql, parameters);
		
		if (result != 0)
			return true;
		else
			return false;
	}
}
