package cn.pluto.www;

public interface LoginActionInterface {
	public String login(String username, String password);
}
